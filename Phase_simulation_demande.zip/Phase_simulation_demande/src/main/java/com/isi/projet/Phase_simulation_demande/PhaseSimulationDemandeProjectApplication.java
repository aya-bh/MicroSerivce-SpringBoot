package com.isi.projet.Phase_simulation_demande;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PhaseSimulationDemandeProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(PhaseSimulationDemandeProjectApplication.class, args);
	}

}

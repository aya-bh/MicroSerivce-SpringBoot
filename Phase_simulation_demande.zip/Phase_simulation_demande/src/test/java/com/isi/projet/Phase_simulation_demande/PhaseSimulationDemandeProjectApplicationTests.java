package com.isi.projet.Phase_simulation_demande;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhaseSimulationDemandeProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}

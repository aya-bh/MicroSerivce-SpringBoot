package com.isi.projet.Phase_decision;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhaseDecisionProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
